# -*- coding: utf-8 -*-

# Copyright: Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)


COMMUNITY_AWS_COLLECTION_NAME = "community.aws"
COMMUNITY_AWS_COLLECTION_VERSION = "7.0.0"
